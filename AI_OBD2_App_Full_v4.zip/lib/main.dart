
import 'package:flutter/material.dart';
import 'screens/live_data.dart';
import 'screens/obd2_connect.dart';
import 'screens/diagnostics.dart';
import 'screens/ai_diagnosis.dart';
import 'screens/emissions_test.dart';
import 'screens/active_test.dart';
import 'screens/export_report.dart';
import 'screens/my_car.dart';
import 'screens/settings.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI OBD2',
      theme: ThemeData.dark(),
      initialRoute: '/live_data',
      routes: {
        '/live_data': (context) => LiveData(),
        '/obd2_connect': (context) => Obd2Connect(),
        '/diagnostics': (context) => Diagnostics(),
        '/ai_diagnosis': (context) => AiDiagnosis(),
        '/emissions_test': (context) => EmissionsTest(),
        '/active_test': (context) => ActiveTest(),
        '/export_report': (context) => ExportReport(),
        '/my_car': (context) => MyCar(),
        '/settings': (context) => Settings(),
      },
    );
  }
}
